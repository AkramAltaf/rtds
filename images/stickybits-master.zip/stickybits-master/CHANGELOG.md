## [3.7.4](https://github.com/dollarshaveclub/stickybits/compare/3.7.3...3.7.4) (2020-02-18)


### fix

* fixes issue with not window scroll issue (#660) ([f8de58c1dea01c56ecd4a6f50f03f90303eff6ca](https://github.com/dollarshaveclub/stickybits/commit/f8de58c1dea01c56ecd4a6f50f03f90303eff6ca)), closes [#660](https://github.com/dollarshaveclub/stickybits/issues/660)

### version

* patch version bump (#659) ([07831c50f667e2926811dc08218f65b368d30efc](https://github.com/dollarshaveclub/stickybits/commit/07831c50f667e2926811dc08218f65b368d30efc)), closes [#659](https://github.com/dollarshaveclub/stickybits/issues/659)



## [3.7.3](https://github.com/dollarshaveclub/stickybits/compare/3.7.2...3.7.3) (2020-01-13)




## [3.7.2](https://github.com/dollarshaveclub/stickybits/compare/3.7.1...3.7.2) (2019-12-18)




## [3.7.1](https://github.com/dollarshaveclub/stickybits/compare/3.7.0...3.7.1) (2019-12-05)




# [3.7.0](https://github.com/dollarshaveclub/stickybits/compare/3.6.8...3.7.0) (2019-11-08)




## [3.6.8](https://github.com/dollarshaveclub/stickybits/compare/3.6.7...3.6.8) (2019-11-05)




## [3.6.7](https://github.com/dollarshaveclub/stickybits/compare/3.6.6...3.6.7) (2019-08-26)




## [3.6.6](https://github.com/dollarshaveclub/stickybits/compare/3.6.5...3.6.6) (2019-05-17)




## [3.6.5](https://github.com/dollarshaveclub/stickybits/compare/3.6.4...3.6.5) (2019-03-31)




## [3.6.4](https://github.com/dollarshaveclub/stickybits/compare/3.6.3...3.6.4) (2019-03-03)




## [3.6.3](https://github.com/dollarshaveclub/stickybits/compare/3.6.2...3.6.3) (2019-03-03)




## [3.6.2](https://github.com/dollarshaveclub/stickybits/compare/3.6.1...3.6.2) (2019-02-20)




## [3.6.1](https://github.com/dollarshaveclub/stickybits/compare/3.6.0...3.6.1) (2018-12-27)




# [3.6.0](https://github.com/dollarshaveclub/stickybits/compare/3.5.8...3.6.0) (2018-12-26)




## [3.5.8](https://github.com/dollarshaveclub/stickybits/compare/3.5.7...3.5.8) (2018-11-30)




## [3.5.7](https://github.com/dollarshaveclub/stickybits/compare/3.5.6...3.5.7) (2018-10-17)




## [3.5.6](https://github.com/dollarshaveclub/stickybits/compare/3.5.5...3.5.6) (2018-10-04)




## [3.5.5](https://github.com/dollarshaveclub/stickybits/compare/3.5.4...3.5.5) (2018-09-13)




## [3.5.4](https://github.com/dollarshaveclub/stickybits/compare/3.5.3...3.5.4) (2018-09-08)




## [3.5.3](https://github.com/dollarshaveclub/stickybits/compare/3.5.2...3.5.3) (2018-08-29)




## [3.5.2](https://github.com/dollarshaveclub/stickybits/compare/3.5.1...3.5.2) (2018-08-26)




## [3.5.1](https://github.com/dollarshaveclub/stickybits/compare/3.5.0...3.5.1) (2018-08-25)




# [3.5.0](https://github.com/dollarshaveclub/stickybits/compare/3.4.1...3.5.0) (2018-08-25)




## [3.4.1](https://github.com/dollarshaveclub/stickybits/compare/3.4.0...3.4.1) (2018-06-30)




# [3.4.0](https://github.com/dollarshaveclub/stickybits/compare/3.3.7...3.4.0) (2018-06-28)




## [3.3.7](https://github.com/dollarshaveclub/stickybits/compare/3.3.5...3.3.7) (2018-06-19)




## [3.3.5](https://github.com/dollarshaveclub/stickybits/compare/3.3.2...3.3.5) (2018-06-14)




## [3.3.2](https://github.com/dollarshaveclub/stickybits/compare/3.3.1...3.3.2) (2018-05-05)




## [3.3.1](https://github.com/dollarshaveclub/stickybits/compare/3.3.0...3.3.1) (2018-04-29)




# [3.3.0](https://github.com/dollarshaveclub/stickybits/compare/3.2.4...3.3.0) (2018-04-25)




## [3.2.4](https://github.com/dollarshaveclub/stickybits/compare/3.2.3...3.2.4) (2018-04-18)


### tests

* use npm ci (#279) ([5050a5727110e71b6991245f2e2dcaa5b583d039](https://github.com/dollarshaveclub/stickybits/commit/5050a5727110e71b6991245f2e2dcaa5b583d039)), closes [#279](https://github.com/dollarshaveclub/stickybits/issues/279)



## [3.2.3](https://github.com/dollarshaveclub/stickybits/compare/3.2.0...3.2.3) (2018-04-10)




# [3.2.0](https://github.com/dollarshaveclub/stickybits/compare/3.1.1...3.2.0) (2018-03-08)




## [3.1.1](https://github.com/dollarshaveclub/stickybits/compare/3.1.0...3.1.1) (2018-02-26)




# [3.1.0](https://github.com/dollarshaveclub/stickybits/compare/3.0.5...3.1.0) (2018-02-25)




## [3.0.5](https://github.com/dollarshaveclub/stickybits/compare/3.0.4...3.0.5) (2018-02-25)




## [3.0.4](https://github.com/dollarshaveclub/stickybits/compare/3.0.3...3.0.4) (2018-02-13)




## [3.0.3](https://github.com/dollarshaveclub/stickybits/compare/3.0.1...3.0.3) (2018-02-13)




## [3.0.1](https://github.com/dollarshaveclub/stickybits/compare/3.0.0...3.0.1) (2018-01-31)




# [3.0.0](https://github.com/dollarshaveclub/stickybits/compare/2.1.2...3.0.0) (2018-01-31)




## [2.1.2](https://github.com/dollarshaveclub/stickybits/compare/2.1.1...2.1.2) (2018-01-24)




## [2.1.1](https://github.com/dollarshaveclub/stickybits/compare/2.0.13...2.1.1) (2018-01-16)




## [2.0.13](https://github.com/dollarshaveclub/stickybits/compare/2.0.10...2.0.13) (2017-12-06)




## [2.0.10](https://github.com/dollarshaveclub/stickybits/compare/2.0.9...2.0.10) (2017-11-09)




## [2.0.9](https://github.com/dollarshaveclub/stickybits/compare/2.0.8...2.0.9) (2017-10-31)




## [2.0.8](https://github.com/dollarshaveclub/stickybits/compare/2.0.7...2.0.8) (2017-10-21)




## [2.0.7](https://github.com/dollarshaveclub/stickybits/compare/2.0.6...2.0.7) (2017-10-20)




## [2.0.6](https://github.com/dollarshaveclub/stickybits/compare/2.0.4...2.0.6) (2017-10-17)




## [2.0.4](https://github.com/dollarshaveclub/stickybits/compare/2.0.3...2.0.4) (2017-10-10)




## [2.0.3](https://github.com/dollarshaveclub/stickybits/compare/2.0.2...2.0.3) (2017-10-06)




## [2.0.2](https://github.com/dollarshaveclub/stickybits/compare/2.0.1...2.0.2) (2017-10-02)




## [2.0.1](https://github.com/dollarshaveclub/stickybits/compare/1.5.3...2.0.1) (2017-09-29)




## [1.5.3](https://github.com/dollarshaveclub/stickybits/compare/1.5.2...1.5.3) (2017-08-06)




## [1.5.2](https://github.com/dollarshaveclub/stickybits/compare/1.5.0...1.5.2) (2017-08-02)




# [1.5.0](https://github.com/dollarshaveclub/stickybits/compare/1.4.4...1.5.0) (2017-07-25)




## [1.4.4](https://github.com/dollarshaveclub/stickybits/compare/1.3.12...1.4.4) (2017-07-25)




## [1.3.12](https://github.com/dollarshaveclub/stickybits/compare/1.3.10...1.3.12) (2017-07-17)




## [1.3.10](https://github.com/dollarshaveclub/stickybits/compare/1.3.8...1.3.10) (2017-07-15)




## [1.3.8](https://github.com/dollarshaveclub/stickybits/compare/1.3.5...1.3.8) (2017-07-04)




## [1.2.10](https://github.com/dollarshaveclub/stickybits/compare/1.2.8...1.2.10) (2017-05-22)




## [1.2.8](https://github.com/dollarshaveclub/stickybits/compare/1.2.7...1.2.8) (2017-04-20)




## [1.2.7](https://github.com/dollarshaveclub/stickybits/compare/1.2.6...1.2.7) (2017-04-19)




## [1.2.6](https://github.com/dollarshaveclub/stickybits/compare/1.2.5...1.2.6) (2017-04-19)




## [1.2.5](https://github.com/dollarshaveclub/stickybits/compare/1.2.4...1.2.5) (2017-04-19)




## [1.2.4](https://github.com/dollarshaveclub/stickybits/compare/1.2.3...1.2.4) (2017-04-19)




## [1.2.3](https://github.com/dollarshaveclub/stickybits/compare/1.1.3...1.2.3) (2017-04-19)




## [1.1.3](https://github.com/dollarshaveclub/stickybits/compare/1.1.2...1.1.3) (2017-04-07)




## [1.1.2](https://github.com/dollarshaveclub/stickybits/compare/1.0.2...1.1.2) (2017-04-01)




## [1.0.2](https://github.com/dollarshaveclub/stickybits/compare/1.0.1...1.0.2) (2017-03-28)




## [1.0.1](https://github.com/dollarshaveclub/stickybits/compare/1.0.0...1.0.1) (2017-03-24)




# [1.0.0](https://github.com/dollarshaveclub/stickybits/compare/0.0.4...1.0.0) (2017-03-23)




## [0.0.4](https://github.com/dollarshaveclub/stickybits/compare/0.0.3...0.0.4) (2017-02-27)




## [0.0.3](https://github.com/dollarshaveclub/stickybits/compare/0.0.2...0.0.3) (2017-02-22)




## 0.0.2 (2017-02-22)




